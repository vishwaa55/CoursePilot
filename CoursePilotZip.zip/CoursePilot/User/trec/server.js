const express = require('express')
const multer= require('multer')
const fs=require('fs')

const csv = require('csv-parser');
const path = require('path')
const app = express()
const { GoogleGenerativeAI } = require('@google/generative-ai');
const port = 5002
const mongoose = require('mongoose') 
const cors=require('cors')
app.use(express.json())
app.use(cors());

// Read the JSON data containing tutor information
const dataPath = path.join(__dirname, 'data.json');
const fileContent = fs.readFileSync(dataPath, 'utf-8');
const tutorData = JSON.parse(fileContent);

const genAI = new GoogleGenerativeAI("AIzaSyCtOiIcDzXPdpNi6yvOSzNzk4eh5CrJmzg");
mongoose.connect('mongodb+srv://user56:test56@cluster0.mcdda.mongodb.net/')
.then(()=>{
    console.log('Connected to MongoDB')
})
.catch((err)=>console.log(err))



app.post('/trec', async(req,res)=>{
    const { field, ExperienceLevel,Cost, CostRange, Duration, LearningPace, PreferredLanguage } = req.body;

    if(!field) return res.status(400).json({msg:"Field not found"})
    if(!ExperienceLevel) return res.status(400).json({msg:"Level not found"})
    if(!Cost) return res.status(400).json({msg:"Cost not found"})
    if(!CostRange) return res.status(400).json({msg:"Costrange not found"})
    if(!Duration) return res.status(400).json({msg:"Duration not found"})
    if(!LearningPace) return res.status(400).json({msg:"Pace not found"})
    if(!PreferredLanguage) return res.status(400).json({msg:"Language not found"})
        
        


        async function queryGemini(field, ExperienceLevel, Cost, CostRange, Duration, LearningPace, PreferredLanguage) {
            try {
                const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        
                const prompt = `
        You are a tutor recommender. Based on the provided information, find the best tutors from the provided data that match the user's specific needs and preferences.
        
        Input:
        {
            "fieldOfIntrest": "${field}",
            "ExperienceLevel": "${ExperienceLevel}",
            "Cost": "${Cost}",
            "CostRange": "${CostRange}",
            "Duration": "${Duration}",
            "LearningPace": "${LearningPace}",
            "PreferredLanguage": "${PreferredLanguage}"
        }
        
        Only use the following tutor data:
        ${JSON.stringify(tutorData, null, 2)}
        
        Please recommend only one tutor that best match the user's criteria. For each tutor, provide:
        - Name
        - Field
        - Cost per Hour
        - Language
        - Rating
        - Benefits (list 3 benefits)
        - Availability
        
        Do not include words such as "for example i'm giving this, there is no data" or similar texts. Just provide the details given above.
        if there is no data file given then generate a example as formate given file and add it to the out put donot send any response that there is no data in dataset
        Ensure the tutors are sorted by highest rating and best fit based on the user's preferences.
        
        Provide the result in the given json format:
    
        {
          "name":"provide the name of the tutor",
          "field":"provide the field of the tutor",
          "rating": "provide the rating",
          "cost": "provide the fees in rupees",
          "language":"provide the language"
        }

                `;
        
                const result = await model.generateContent(prompt);
        
                const generateText = result.response.candidates[0]?.content;
                console.log(generateText);
                return generateText || 'No content generated.';
            } catch (error) {
                console.error('Error querying Gemini:', error);
                return null;
            }
        }
        

        try {
            const tutorRecommendations = await queryGemini( field, ExperienceLevel, Cost, CostRange, Duration, LearningPace, PreferredLanguage);
            if (!tutorRecommendations) {
                return res.status(500).json({ error: 'Failed to generate tutor recommendations' });
            }
            res.json({ recommendations: tutorRecommendations });
        } catch (error) {
            console.error('Error in /recommend-tutor:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
        });
        
        // Serve the frontend files (optional if using separate frontend)
        app.use(express.static('public'));




app.listen(port,()=>console.log(`server is listening ${port}`))