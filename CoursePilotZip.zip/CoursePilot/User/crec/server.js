const express = require('express')
const multer= require('multer')
const fs=require('fs')

const csv = require('csv-parser');
const path = require('path')
const app = express()
const { GoogleGenerativeAI } = require('@google/generative-ai');
const port = 5001
const mongoose = require('mongoose') 
const cors=require('cors')
app.use(express.json())
app.use(cors());


const genAI = new GoogleGenerativeAI('AIzaSyCtOiIcDzXPdpNi6yvOSzNzk4eh5CrJmzg');
mongoose.connect('mongodb+srv://user56:test56@cluster0.mcdda.mongodb.net/')
.then(()=>{
    console.log('Connected to MongoDB')
})
.catch((err)=>console.log(err))

const courses = [];

fs.createReadStream('sample.csv')
  .pipe(csv())
  .on('data', (row) => {
    courses.push(row);
  })
  .on('end', () => {
    console.log('CSV file successfully processed');
    // Proceed with processing the tutors array
  })
  .on('error', (error) => {
    console.error(error);
  });



app.post('/crec', async(req,res)=>{
    const { field, ExperienceLevel,Cost, CostRange, Duration, LearningPace, PreferredLanguage } = req.body;

    if(!field) return res.status(400).json({msg:"Field not found"})
    if(!ExperienceLevel) return res.status(400).json({msg:"Level not found"})
    if(!Cost) return res.status(400).json({msg:"Cost not found"})
    if(!CostRange) return res.status(400).json({msg:"Costrange not found"})
    if(!Duration) return res.status(400).json({msg:"Duration not found"})
    if(!LearningPace) return res.status(400).json({msg:"Pace not found"})
    if(!PreferredLanguage) return res.status(400).json({msg:"Language not found"})
        



        async function queryGemini(field, ExperienceLevel, Cost, CostRange, Duration, LearningPace, PreferredLanguage) {
            try {
                const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        
                const prompt = `
        You are a course recommender. Based on the provided information, find the best courses from the provided data that match the user's specific needs and preferences.
        
        Input:
        {
            "FieldOfInterest": "${field}",
            "ExperienceLevel": "${ExperienceLevel}",
            "Cost": "${Cost}",
            "CostRange": "${CostRange}",
            "Duration": "${Duration}",
            "LearningPace": "${LearningPace}",
            "PreferredLanguage": "${PreferredLanguage}"
        }
        Only use the data from:
        ${JSON.stringify(courses, null, 2)}
        
        Please recommend only one course that best match the user's criteria. For each course, provide:
        - Course Name
        - Course url
        - Rating
        - Cost (Free/Paid)
          if(Free)
            -Amount= 0
          if(Paid)
            - Amount= Amount
        - Language
        - Benefits (list 3 benefits)
        Do not include words such as "for example i'm giving this, there is no data" or similar texts. Just provide the details given above.
        If there is no data file given then generate a example as formate given file and add it to the out put do not send any response that there is no data in dataset
        Ensure the tutors are sorted by highest rating and best fit based on the user's preferences.
        
        Provide the result in the given json format:
        

        {
          "coursename":"provide the course name",
          "url":"provide the course url",
          "rating": "provide the rating",
          "cost": "provide the cost in rupees",
          "language":"provide the language",
          "benefit1":"provide the benefit-1",
          "benefit2":"provide the benefit-2",
          "benefit3":"provide the benefit-3"
        }

        
                `;
        
                const result = await model.generateContent(prompt);
        
                const generateText = result.response.candidates[0]?.content;
                console.log(generateText);
                return generateText || 'No content generated.';
            } catch (error) {
                console.error('Error querying Gemini:', error);
                return null;
            }
        }
        

        try {
            const courseRecommendations = await queryGemini( field, ExperienceLevel, Cost, CostRange, Duration, LearningPace, PreferredLanguage);
            if (!courseRecommendations) {
                return res.status(500).json({ error: 'Failed to generate tutor recommendations' });
            }
            return res.json({ msg: courseRecommendations.parts[0].text });
        } catch (error) {
            console.error('Error in /recommend-course:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
});





app.listen(port,()=>console.log(`server is listening ${port}`))