const express = require('express');
const multer = require('multer');
const path = require('path');
const cors = require('cors');
const pdf=require('pdf-parse')
const {GoogleGenerativeAI} = require('@google/generative-ai');
const genAI = new GoogleGenerativeAI("AIzaSyD2j5MWuEFMb1uEofq_Ohmb0sKOWVhfd44");
const app = express();
const port = 3000;
app.use(cors({
    origin: 'http://localhost:5500', 
    methods: ['GET', 'POST', 'OPTIONS'],
    credentials: true
    }));
const storage = multer.diskStorage(
    {
    destination: function (req, file, cb)
    {
        cb(null, 'uploads');
    },
    filename: function (req, file, cb)
    {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer(
    {
    storage: storage,
    fileFilter: (req, file, cb) =>
    {
        if (file.mimetype === 'application/pdf')
        {
            cb(null, true); 
        }
        else
        {
            cb(new Error('Only PDF files are allowed'), false);
        }
    },
});
app.post('/career-suggestion', upload.single('resume'),async (req, res) => {
    if (!req.file)
    {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    const text=req.file
    async function queryGemini(text)
    {
        try
        {
            const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
            const prompt = `
                Imagine that you're an expert in Carer guidance. An individuals's resume is given to you as ${text}.
                Analyze the information in the resume and provide your view on it and suggest skills that imrpovise the resume in their own field
                the report must be profession and the suggestions must be specific.
            `;
            const result = await model.generateContent(prompt)
            const generateText = result.response.candidates[0]?.content;
            console.log(generateText);
            return generateText || 'No content generated.';
        }
        catch(error)
        {
            console.error('Error querying Gemini:', error);
            return null;
        }
    }
    try
    {
        const careerSuggestion = await queryGemini(text);
        if (!careerSuggestion)
        {
            return res.status(500).json({ error: 'Failed to generate tutor recommendations' });
        }
        return res.json({ sug: careerSuggestion });
    } catch(error)
    {
        console.error('Error in /recommend-course:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
    // Generate a unique job ID or session ID
    const jobId = Date.now();
    // Here you can implement any logic to analyze the resume
    //const careerSuggestion = `We analyzed your resume: ${req.file.originalname}. Based on the content, we suggest exploring careers in Software Engineering, Data Science, or DevOps.`;
    // Send the suggestion back along with the jobId
    res.json({ msg: careerSuggestion, jobId: jobId });
});
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});